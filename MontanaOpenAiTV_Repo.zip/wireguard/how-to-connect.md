# Cómo conectarse con WireGuard (MontanaOpenAiTV)

1. Instala WireGuard en tu dispositivo (iPhone, Android, Windows, macOS, Linux).
2. Carga el archivo `montana-client.conf`.
3. Conéctate. Tu IP local será 10.0.0.2 dentro de la VPN.
4. Accede a tu servidor AceStream como si estuvieras en casa.
5. Usa MontanaOpenAiTV y reproduce cualquier ID como si estuvieras en tu red local.

⚠️ Asegúrate de tener el puerto UDP 51820 abierto en tu router y redirigido al dispositivo servidor.
